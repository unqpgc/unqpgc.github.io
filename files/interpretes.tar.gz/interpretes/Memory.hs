
module Memory(Addr, Memory, emptyMemory, allocate, store, dereference) where

type Addr = Int
data Memory a = MM [(Addr, a)]

instance Show (Memory a) where
  show (MM _) = "<memoria>"

emptyMemory :: Memory a
emptyMemory = MM []

allocate :: Memory a -> Addr
allocate (MM []) = 0
allocate (MM xs) = maximum (map fst xs) + 1

store :: Memory a -> Addr -> a -> Memory a
store (MM xs) a b = MM ((a, b) : xs)

dereference :: Memory a -> Addr -> a
dereference (MM xs) a =
  case lookup a xs of
    Just b  -> b
    Nothing -> error "La dirección de memoria no está."

