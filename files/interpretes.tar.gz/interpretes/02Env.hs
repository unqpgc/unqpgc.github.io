import Environment

data Expr = ExprConstNum Int
          | ExprConstBool Bool
          | ExprAdd Expr Expr
          | ExprVar Id
          | ExprLet Id Expr Expr

data Val = VN Int
         | VB Bool
  deriving Show

addVal :: Val -> Val -> Val
addVal (VN a) (VN b) = VN (a + b)
addVal _ _           = error "Los valores no son numéricos."

eval :: Expr -> Env Val -> Val
eval (ExprConstNum n)  env = VN n
eval (ExprConstBool b) env = VB b
eval (ExprAdd e1 e2)   env = eval e1 env `addVal` eval e2 env
eval (ExprVar x)       env = lookupEnv env x
eval (ExprLet x e1 e2) env = eval e2 (extendEnv env x (eval e1 env))

ejemplo :: Expr
ejemplo =
  ExprLet "x"
    (ExprConstNum 5)
    (ExprLet "y" (ExprAdd (ExprVar "x") (ExprVar "x"))
      (ExprLet "y" (ExprAdd (ExprVar "x") (ExprVar "y"))
        (ExprVar "y")))

