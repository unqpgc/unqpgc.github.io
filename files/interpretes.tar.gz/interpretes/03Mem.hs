import Environment
import Memory

data Expr = ExprConstNum Int
          | ExprConstBool Bool
          | ExprAdd Expr Expr
          | ExprVar Id
          | ExprLet Id Expr Expr
          | ExprSeq Expr Expr
          | ExprAssign Id Expr

data Val = VN Int
         | VB Bool
  deriving Show

addVal :: Val -> Val -> Val
addVal (VN a) (VN b) = VN (a + b)
addVal _ _           = error "Los valores no son numéricos."

eval :: Expr -> Env Addr -> Memory Val -> (Val, Memory Val)
eval (ExprConstNum n)  env mem0 = (VN n, mem0)
eval (ExprConstBool b) env mem0 = (VB b, mem0)
eval (ExprAdd e1 e2)   env mem0 =
  let (v1, mem1) = eval e1 env mem0
      (v2, mem2) = eval e2 env mem1
   in (v1 `addVal` v2, mem2)
eval (ExprVar x)       env mem0 = (dereference mem0 (lookupEnv env x), mem0)
eval (ExprLet x e1 e2) env mem0 =
  let (v1, mem1) = eval e1 env mem0
      ptr = allocate mem1
      (v2, mem2) = eval e2 (extendEnv env x ptr) (store mem1 ptr v1)
   in (v2, mem2)
eval (ExprSeq e1 e2) env mem0 =
  let (v1, mem1) = eval e1 env mem0
      (v2, mem2) = eval e2 env mem1
   in (v2, mem2)
eval (ExprAssign x e) env mem0 =
  let (v1, mem1) = eval e env mem0 in
    (VN 0, store mem1 (lookupEnv env x) v1)

ejemplo :: Expr
ejemplo =
  ExprLet "x"
    (ExprConstNum 5)
    (ExprLet "y" (ExprConstNum 1)
      (ExprSeq
        (ExprAssign "x" (ExprAdd (ExprVar "x") (ExprVar "y")))
        (ExprSeq
          (ExprAssign "x" (ExprAdd (ExprVar "x") (ExprVar "y")))
          (ExprSeq
            (ExprAssign "x" (ExprAdd (ExprVar "x") (ExprVar "y")))
            (ExprVar "x")))))

