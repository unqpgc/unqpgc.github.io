import Environment
import Memory

data Expr = ExprConstNum Int
          | ExprConstBool Bool
          | ExprAdd Expr Expr
          | ExprVar Id
          | ExprLet Id Expr Expr
          | ExprSeq Expr Expr
          | ExprAssign Id Expr
          --
          | ExprLtNum Expr Expr
          | ExprIf Expr Expr Expr
          | ExprWhile Expr Expr

data Val = VN Int
         | VB Bool
  deriving Show

addVal :: Val -> Val -> Val
addVal (VN a) (VN b) = VN (a + b)
addVal _ _           = error "Los valores no son numéricos."

ltNumVal :: Val -> Val -> Val
ltNumVal (VN a) (VN b) = VB (a < b)
ltNumVal _ _           = error "Los valores no son numéricos."

isTrueVal :: Val -> Bool
isTrueVal (VB b) = b
isTrueVal _      = False

eval :: Expr -> Env Addr -> Memory Val -> (Val, Memory Val)
eval (ExprConstNum n)  env mem0 = (VN n, mem0)
eval (ExprConstBool b) env mem0 = (VB b, mem0)
eval (ExprAdd e1 e2)   env mem0 =
  let (v1, mem1) = eval e1 env mem0
      (v2, mem2) = eval e2 env mem1
   in (v1 `addVal` v2, mem2)
eval (ExprVar x)       env mem0 = (dereference mem0 (lookupEnv env x), mem0)
eval (ExprLet x e1 e2) env mem0 =
  let (v1, mem1) = eval e1 env mem0
      ptr = allocate mem1
      (v2, mem2) = eval e2 (extendEnv env x ptr) (store mem1 ptr v1)
   in (v2, mem2)
eval (ExprSeq e1 e2) env mem0 =
  let (v1, mem1) = eval e1 env mem0
      (v2, mem2) = eval e2 env mem1
   in (v2, mem2)
eval (ExprAssign x e) env mem0 =
  let (v1, mem1) = eval e env mem0 in
    (VN 0, store mem1 (lookupEnv env x) v1)
eval (ExprLtNum e1 e2) env mem0 =
  let (v1, mem1) = eval e1 env mem0
      (v2, mem2) = eval e2 env mem1
   in (v1 `ltNumVal` v2, mem2)
eval (ExprIf e1 e2 e3) env mem0 =
  let (v1, mem1) = eval e1 env mem0 in
    if isTrueVal v1
     then eval e2 env mem1
     else eval e3 env mem1
eval (ExprWhile e1 e2) env mem0 =
  let (v1, mem1) = eval e1 env mem0 in
    if isTrueVal v1
     then
       let (v2, mem2) = eval e2 env mem1 in
         eval (ExprWhile e1 e2) env mem2
     else (VN 0, mem1)

ejemploIf :: Expr
ejemploIf =
  ExprLet "x" (ExprConstNum 21)
    (ExprLet "cond" (ExprConstBool True)
      (ExprIf (ExprVar "cond")
              (ExprAdd (ExprVar "x") (ExprVar "x"))
              (ExprConstNum 0)))

ejemploWhile :: Expr
ejemploWhile =
  ExprLet "x" (ExprConstNum 0)
    (ExprLet "y" (ExprConstNum 1)
      (ExprSeq
        (ExprWhile (ExprLtNum (ExprVar "x") (ExprConstNum 7))
           (ExprSeq
             (ExprAssign "x" (ExprAdd (ExprVar "x") (ExprConstNum 1)))
             (ExprAssign "y" (ExprAdd (ExprVar "y") (ExprVar "y")))))
        (ExprVar "y")))

