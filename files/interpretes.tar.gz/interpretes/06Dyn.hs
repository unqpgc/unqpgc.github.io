import Environment

data Expr = ExprVar Id
          | ExprLam Id Expr
          | ExprApp Expr Expr
          | ExprConstNum Int
          | ExprConstBool Bool
          | ExprAdd Expr Expr
          | ExprLet Id Expr Expr
          | ExprIf Expr Expr Expr
  deriving Show

data Val = VN Int
         | VB Bool
         | VFunction Id Expr

instance Show Val where
  show (VN n)          = "VN " ++ show n
  show (VB b)          = "VB " ++ show b
  show (VFunction _ _) = "<función>"

addVal :: Val -> Val -> Val
addVal (VN a) (VN b) = VN (a + b)
addVal _ _           = error "Los valores no son numéricos."

isTrueVal :: Val -> Bool
isTrueVal (VB b) = b
isTrueVal _      = False

eval :: Expr -> Env Val -> Val
eval (ExprVar x)      env = lookupEnv env x
eval (ExprLam x e)    env = VFunction x e
eval (ExprApp e1 e2)  env =
  let v1 = eval e1 env
      v2 = eval e2 env
   in case v1 of
        VFunction x e1' -> eval e1' (extendEnv env x v2)
        _ -> error "Lo que se aplica no es una función."
eval (ExprConstNum n)  env = VN n
eval (ExprConstBool b) env = VB b
eval (ExprAdd e1 e2)   env = eval e1 env `addVal` eval e2 env
eval (ExprLet x e1 e2) env = eval e2 (extendEnv env x (eval e1 env))
eval (ExprIf e1 e2 e3) env =
  if isTrueVal (eval e1 env)
   then eval e2 env
   else eval e3 env

ejemplo :: Expr
ejemplo =
  ExprLet "suma" (ExprLam "x"
                   (ExprLam "y"
                     (ExprAdd (ExprVar "x") (ExprVar "y"))))
    (ExprLet "f" (ExprApp (ExprVar "suma") (ExprConstNum 5))
      (ExprLet "x" (ExprConstNum 0)
        (ExprApp (ExprVar "f") (ExprConstNum 3))))

