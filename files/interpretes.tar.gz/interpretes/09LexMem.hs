import Control.Monad.State(State, evalState, get, put)

import Environment
import Memory

data Expr = ExprVar Id
          | ExprAssign Id Expr
          | ExprLam Id Expr
          | ExprApp Expr Expr
          | ExprLet Id Expr Expr
          | ExprConstNum Int
          | ExprConstBool Bool
          | ExprAdd Expr Expr
          | ExprIf Expr Expr Expr

data Val = VN Int
         | VB Bool
         | VClosure Id Expr (Env Addr)

instance Show Val where
  show (VN n)           = "VN " ++ show n
  show (VB b)           = "VB " ++ show b
  show (VClosure _ _ _) = "<clausura>"

addVal :: Val -> Val -> Val
addVal (VN a) (VN b) = VN (a + b)
addVal _ _           = error "Los valores no son numéricos."

isTrueVal :: Val -> Bool
isTrueVal (VB b) = b
isTrueVal _      = False

eval :: Expr -> Env Addr -> Memory Val -> Val
eval e env mem = evalState (evalM e env) mem

type M = State (Memory Val)

new :: Val -> M Addr
new v = do
  mem <- get
  let ptr = allocate mem in do
    put (store mem ptr v)
    return ptr

evalM :: Expr -> Env Addr -> M Val
evalM (ExprVar x) env = do
  mem <- get
  return (dereference mem (lookupEnv env x))
evalM (ExprAssign x e) env = do
  v <- evalM e env
  mem <- get
  put (store mem (lookupEnv env x) v)
  return (VN 0)
evalM (ExprLam x e)   env = return (VClosure x e env)
evalM (ExprApp e1 e2) env = do
  v1 <- evalM e1 env
  v2 <- evalM e2 env
  case v1 of
    VClosure x e1' envOrig -> do
      ptr <- new v2
      evalM e1' (extendEnv envOrig x ptr)
    _ -> error "Lo que se aplicó no es una función."
evalM (ExprLet x e1 e2) env = do
  v1 <- evalM e1 env
  ptr <- new v1
  evalM e2 (extendEnv env x ptr)
evalM (ExprConstNum n) env  = return (VN n)
evalM (ExprConstBool b) env = return (VB b)
evalM (ExprAdd e1 e2) env = do
  v1 <- evalM e1 env
  v2 <- evalM e2 env
  return (v1 `addVal` v2)
evalM (ExprIf e1 e2 e3) env = do
  v1 <- evalM e1 env
  if isTrueVal v1
   then evalM e2 env
   else evalM e3 env

