
data Expr = ExprConstNum Int
          | ExprAdd Expr Expr

eval :: Expr -> Int
eval (ExprConstNum n) = n
eval (ExprAdd e1 e2)  = eval e1 + eval e2

